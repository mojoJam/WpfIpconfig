﻿using System;
using System.Text.RegularExpressions;
 

namespace WpfIpconfig.Utils
{
    public class LastSign
    {



        private const string reduceMultiSpace = @"[ ]{2,}";

        private static Regex WithCrLf = new Regex("[\r\n]");



        public static string combi_of_remove(string text)
        {
            return Remove_Sign_crlf_from_String(Remove_Sign_vbtab_from_String(Last_One_Sign_Remove_from_String(text, ";")));
        }

        public static string Remove_Sign_crlf_from_String(string strWithCrLf)
        {

            return WithCrLf.Replace(strWithCrLf, "");

        }

        public static string Remove_Sign_vbtab_from_String(string strWithTabs)
        {

            string line = strWithTabs.Replace("\t", "");
            return Regex.Replace(strWithTabs.Replace("\t", ""), reduceMultiSpace, "");

        }


        public static string Last_One_Sign_Remove_from_String(string text, string sign)
        {
            if (text.EndsWith(sign))
            {
                return text.Remove(text.Length - 1);
            }

            return text;
        }


    }
}
