﻿using System;
using System.Text.RegularExpressions;


namespace WpfIpconfig.Utils
{
    public static class LibDirectNumeric
    {

        /// <summary>
        /// NumberRange für die natürlichen Zahlen mit Null das Symbol N0
        /// </summary>
        private static Regex regexPatternNumberRangeN0 = new Regex("^[0-9]+$");
        //private static Regex intRegexPatternWith = new Regex(@"(?<=^| )\d+(\.\d+)?(?=$| )|(?<=^| )\.\d+(?=$| )");
        // private static Regex intRegexPatternWith = new Regex(@"(?<=^)\d+(\.\d+)?(?=$)|(?<=^)\.\d+(?=$)");
        //   private static Regex intRegexPatternWith = new Regex(@"(?<=^| )\d+(\.\d+)?(?=$| )|(?<=^| )\.\d+(?=$| )");
        //
        //==============================================================
        //==============================================================
        //

        /// <summary>
        /// "1.1" = false; "1" = true
        /// </summary>
        /// <param name="targetVal"></param>
        /// <returns></returns>
        public static bool isNumericNumberRangeN0(this string targetVal)
        {
            return regexPatternNumberRangeN0.IsMatch(targetVal);
        }



        //
        //==============================================================
        //==============================================================
        //

        private static string TypeofNames = "String,Byte,Decimal,Double,Int16,Int32,Int64," +
                                            "SByte,Single,UInt16,UInt32,UInt64,";



        /// <summary>
        /// "1.1" = false; "1" = true
        /// </summary>
        /// <param name="targetVal"></param>
        /// <returns></returns>
        public static bool isNumericTypeWithNumberRangeN0(this string targetVal)
        {

            if (targetVal != null &&
                TypeofNames.Contains(targetVal.GetType().Name.ToString() + ","))
            {
                return targetVal.isNumericNumberRangeN0();
            }
            return false;
        }


        /// <summary>
        /// "1.1" = false; "1" = true
        /// </summary>
        /// <param name="targetVal"></param>
        /// <returns></returns>
        public static bool isNumericTypeWithNumberRangeN0(this object targetVal)
        {
            try
            {
                if (targetVal != null &&
                    TypeofNames.Contains(targetVal.GetType().Name.ToString() + ","))
                {
                    return targetVal.ToString().isNumericNumberRangeN0();
                }
            }
            catch
            { }
            return false;

        }

        //
        //==============================================================
        //==============================================================
        //

        /// <summary>
        /// Stehengelassene Methode
        /// Regex mit Zeichen Übergabe
        /// "1.1 " = true; "1,1," = true aus isNumericTypeWithNumberRangeN0
        /// </summary>
        /// <param name="targetVal"></param>
        /// <returns></returns>
        public static bool isNumericTypeWithNumberRangeN0XorSign(this string targetVal, string sign)
        {

            char gf = '\u0022';
            Regex intRegexPatternWith = new Regex(String.Format(@"(?<=^|[{0}])\d+(\.\d+)?(?=$|[{0}])|(?<=^|[{0}])\.\d+(?=$|[{0}])", sign, gf));
            //Regex intRegexPatternWith = new Regex(String.Format("[^,]", "[" + sign + "]", gf, bsl));
            //Regex intRegexPatternWith = new Regex("\\d+[,]|\\d+");
            if (targetVal != null &&
                TypeofNames.Contains(targetVal.GetType().Name.ToString() + ","))
            {
                return intRegexPatternWith.IsMatch(targetVal);
            }
            return false;
        }






    }
}
