﻿using System;


namespace WpfIpconfig.ViewModels
{
    public partial class MainWindowVm
    {

        public MainWindowVm()
        {
            inputInterval = "300";
            start_BuDeEnabled = true;
            cancel_BuDeEnabled = false;
        }


    }
}
