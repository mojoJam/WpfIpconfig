﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Threading;
using WpfIpconfig.Interfaces;
 

namespace WpfIpconfig.ViewModels
{
    public partial class MainWindowVm : INotifyPropertyChanged, IMainWindowVm
    {
                                   
        public string inputInterval
        {
            get { return _inputInterval; }
            set
            {
                _inputInterval = value;
                RaisePropertyChanged(() => this.inputInterval);
            }
        }
        private string _inputInterval;


        public string messageText
        {
            get { return _messageText; }
            set
            {
                _messageText = value;
                RaisePropertyChanged(() => this.messageText);
            }
        }
        private string _messageText;
         
       

        public bool cancel_BuDeEnabled
        {
            get { return _cancel_BuDeEnabled; }
            set
            {
                _cancel_BuDeEnabled = value;
                RaisePropertyChanged(() => this.cancel_BuDeEnabled);
            }
        }
        private bool _cancel_BuDeEnabled;

        public bool start_BuDeEnabled
        {
            get { return _start_BuDeEnabled; }
            set
            {
                _start_BuDeEnabled = value;
                RaisePropertyChanged(() => this.start_BuDeEnabled);
            }
        }
        private bool _start_BuDeEnabled;


        public virtual bool HasError
        {
            get { return _hasError; }
            set
            {               
                _hasError = value;
                RaisePropertyChanged(() => HasError);
            }
        }
        private bool _hasError = false;   
        


        private CancellationTokenSource ctsMain = new CancellationTokenSource();

        // Fine
        //////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        // Start PropertyChanged


        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged<T>(Expression<Func<T>> x)
        {
            var body = x.Body as MemberExpression;

            if (body != null)
            {

                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs(body.Member.Name));
                   
                }

                //if (body.Member.Name == GetPropertyName(() => this.inputInterval))
                //{
                     

                //}

            }
        }



        public string GetPropertyName<T>(Expression<Func<T>> expression)
        {
            System.Linq.Expressions.MemberExpression memberExpression = (MemberExpression)expression.Body;
            return memberExpression.Member.Name;
        }


         

    }
}
