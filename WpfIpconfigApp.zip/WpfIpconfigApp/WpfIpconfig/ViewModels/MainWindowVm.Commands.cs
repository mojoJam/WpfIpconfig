﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Input;
using System.Windows.Threading;
using WpfIpconfig.Commands;
using WpfIpconfig.Interfaces;


namespace WpfIpconfig.ViewModels
{
    public partial class MainWindowVm
    {



        public ICommand cancel_BuCmd
        {
            get
            {
                if (_cancel_BuCmd == null)
                {
                    _cancel_BuCmd =
                         new RelayCommand(
                                (param) =>
                                {
                                    var xx = cancel_BuCmdMeth(param);
                                });
                }
                return _cancel_BuCmd;
            }
        }
        private ICommand _cancel_BuCmd;



        public ICommand start_BuCmd
        {
            get
            {
                if (_start_BuCmd == null)
                {
                    _start_BuCmd =
                         new RelayCommand(
                                (param) =>
                                {
                                    var xx = start_BuCmdMeth(param);
                                });
                }
                return _start_BuCmd;
            }
        }
        private ICommand _start_BuCmd;



        public async Task<int> cancel_BuCmdMeth(object obj)
        {
            await Task.Delay(0);

            if (!(ctsMain == null))
            {
                ctsMain.Cancel();
                aTimer.Stop();
                aTimer.Enabled = false;
            }


            cancel_BuDeEnabled = false;
            start_BuDeEnabled = true;

            return 100;

        }






        public async Task<int> start_BuCmdMeth(object obj)
        {
            await Task.Delay(0);

            if (HasError)
            {
                return 100;
            }
            cancel_BuDeEnabled = true;
            start_BuDeEnabled = false;
            ctsMain = new System.Threading.CancellationTokenSource();

            int re = await Task.Run(() => startInterval(ctsMain.Token, this));

            return 100;
        }
        //ctsMain.Token,   CancellationToken cancellationToken, 
        private int startInterval(CancellationToken cancellationToken, IMainWindowVm imainWindowVm)
        {


            try
            {
                int seconds = Convert.ToInt32(imainWindowVm.inputInterval);
                initTimer(cancellationToken, imainWindowVm);
            }
            catch (Exception ex)
            {
                imainWindowVm.messageText = ex.Message.ToString();
            }

            return 100;

        }

        System.Timers.Timer aTimer = new System.Timers.Timer();

        private void initTimer(CancellationToken cancellationToken, IMainWindowVm imainWindowVm)
        {

            aTimer = new System.Timers.Timer();
            aTimer.Interval = Convert.ToDouble(imainWindowVm.inputInterval) * 1000;
            aTimer.Elapsed += (sender, e) => timer_Tick(sender, e, imainWindowVm, cancellationToken);

            aTimer.Enabled = true;
            runCmd_Ipconfig(cancellationToken, imainWindowVm);
            aTimer.Start();

        }

        private void timer_Tick(object sender, EventArgs e, IMainWindowVm imainWindowVm, CancellationToken cancellationToken)
        {

            runCmd_Ipconfig(cancellationToken, imainWindowVm);


        }

        private int elapsedTime;
        private ManualResetEvent m_processExited = new ManualResetEvent(false);
        private bool eventHandled;

        private void ProcessExited(object sender, EventArgs args)
        {
            // This is where you can add some code to be
            // executed before this program exits.

            m_processExited.Set();
            eventHandled = true;
        }




        private void runCmd_Ipconfig(CancellationToken cancellationToken, IMainWindowVm imainWindowVm)
        {


            Exception responseException = new Exception();

            try
            {
                using (Process process = new Process())
                {

                    process.StartInfo.FileName = "cmd.exe";
                    process.StartInfo.Arguments = "/C ipconfig /flushdns";
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.Exited += ProcessExited;
                    process.Start();


                    StreamReader reader = process.StandardOutput;
                    string output = reader.ReadToEnd();
                    imainWindowVm.messageText = output;

                    process.WaitForExit(5000);
                    cancellationToken.ThrowIfCancellationRequested();
                    //if (cancellationToken.IsCancellationRequested)
                    //{
                    //    throw new TaskCanceledException();

                    //}

                }



            }
            catch (OperationCanceledException operationCanceledException)
            {
                responseException = operationCanceledException;
                imainWindowVm.messageText = operationCanceledException.Message.ToString();

            }
            catch (Exception ex)
            {
                responseException = ex;
                imainWindowVm.messageText = responseException.Message.ToString();
                if (!(ctsMain == null))
                {
                    ctsMain.Cancel();

                }
                

            }


        }


    }
}
