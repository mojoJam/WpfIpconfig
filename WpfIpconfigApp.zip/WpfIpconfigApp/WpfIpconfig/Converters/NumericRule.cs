﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using WpfIpconfig.Utils;


namespace WpfIpconfig.Converters
{
    public class NumericRule : ValidationRule
    {
        private int _min;
        private int _max;
        //private int _partLengthMin;
        //private int _partLengthMax;

        public NumericRule()
        {
        }

        public int Min
        {
            get { return _min; }
            set { _min = value; }
        }

        public int Max
        {
            get { return _max; }
            set { _max = value; }
        }

        //public int PartLengthMin
        //{
        //    get { return _partLengthMin; }
        //    set { _partLengthMin = value; }
        //}

        //public int PartLengthMax
        //{
        //    get { return _partLengthMax; }
        //    set { _partLengthMax = value; }
        //}

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {

            string validationResultText;
            try
            {

                if (value == null)
                {
                    return ValidationResult.ValidResult;
                }
                string[] split1d = MakeStringSplitby_Splitterlen1toArrayString1D(LastSign.combi_of_remove(Convert.ToString(value)), ';');

                if (split1d.Length > 0)
                {
                    for (int a_0_0 = 0; a_0_0 < split1d.Length; a_0_0++)
                    {
                        split1d[a_0_0] = split1d[a_0_0].Trim();
                        validationResultText = doCheck(split1d[a_0_0]);

                        if (validationResultText.Length > 0)
                        {
                            return new ValidationResult(false, validationResultText);
                        }


                    }

                }
                else
                {
                    return ValidationResult.ValidResult;
                    //validationResultText = doCheck(split1d[0]);
                    //if (validationResultText.Length > 0)
                    //{
                    //    return new ValidationResult(false, validationResultText);
                    //}
                }

            }
            catch (Exception e)
            {
                //"Illegal characters or "
                return new ValidationResult(false, "Something wrong" + e.Message);
            }

            return ValidationResult.ValidResult;

        }

        private string doCheck(string value)
        {
            string response = String.Empty;
            //

            if (!LibDirectNumeric.isNumericTypeWithNumberRangeN0(value))
            {
                string invalidSign = string.Empty;
                for (int hChar = 0; hChar < value.Length; hChar++)
                {
                    invalidSign = Convert.ToString(value[hChar]);
                }
                if (invalidSign.Length > 0)
                {
                    return String.Format("Value, {0}, must be numeric. First invalid character: {1}", value, invalidSign);
                }
                return String.Format("Value, {0}, must be numeric", value);

            }
            //else if (!(value.Length == PartLength))
            //{
            //    return String.Format("Wert, {0}, muss {1} Stellen lang sein", value, PartLength);


            //}
            else
            {
                int valueInt = Int32.Parse(value);

                if ((valueInt < Min) || (valueInt > Max))
                {
                    return String.Format("Number, {0}, must be in a range of {1} and {2}", valueInt, Min, Max);
                }

            }


            return response;
        }

        public string[] MakeStringSplitby_Splitterlen1toArrayString1D(string yearValues, char splitter)
        {
            string[] back1d = new string[] { };
            if (yearValues.IndexOf(splitter) + 1 > 0)
            {
                string[] backTmp1d = LastSign.Last_One_Sign_Remove_from_String(yearValues, splitter.ToString()).Split(splitter);
                int cntinBack1D = -1;
                for (int hcnt = 0; hcnt < backTmp1d.Length; hcnt++)
                {
                    if (backTmp1d[hcnt].Trim().Length > 0)
                    {
                        cntinBack1D++;
                        Array.Resize<string>(ref back1d, cntinBack1D + 1);
                        back1d[cntinBack1D] = backTmp1d[hcnt].Trim();
                    }

                }

            }
            else if (yearValues.Trim().Length > 0)
            {
                Array.Resize<string>(ref back1d, 1);
                back1d[0] = yearValues.Trim();
            }

            return back1d;
        }



    }
}
