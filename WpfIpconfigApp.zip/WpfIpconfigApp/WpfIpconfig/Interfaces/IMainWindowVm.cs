﻿using System;
using System.Threading;
 

namespace WpfIpconfig.Interfaces
{
    public interface IMainWindowVm
    {

        string messageText { get; set; }
        string inputInterval { get; set; }
          

          
    }
}
